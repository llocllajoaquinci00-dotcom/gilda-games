function accountDestination() {
    const next = new URLSearchParams(location.search).get('next') || 'biblioteca.html';
    return /^[a-z0-9_-]+\.html(?:\?.*)?$/i.test(next) ? next : 'biblioteca.html';
}

function renderAccountPage() {
    const signedIn = Boolean(Gilda.user);
    document.querySelector('#account-auth').hidden = signedIn;
    document.querySelector('#account-profile').hidden = !signedIn;
    if (signedIn) {
        const name = Gilda.user.user_metadata?.display_name || Gilda.user.email.split('@')[0];
        document.querySelector('#profile-name').textContent = `Hola, ${name}.`;
        document.querySelector('#profile-email').textContent = Gilda.user.email;
    }
}

function setAuthTab(name) {
    document.querySelectorAll('[data-auth-tab]').forEach((tab) => tab.classList.toggle('active', tab.dataset.authTab === name));
    document.querySelectorAll('[data-auth-form]').forEach((form) => form.classList.toggle('active', form.dataset.authForm === name));
    Gilda.setMessage('#auth-message', '');
}

document.querySelector('.auth-tabs').addEventListener('click', (event) => {
    const tab = event.target.closest('[data-auth-tab]');
    if (tab) setAuthTab(tab.dataset.authTab);
});

document.querySelector('#register-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!Gilda.client) return Gilda.setMessage('#auth-message', 'No se pudo conectar a Supabase.', true);
    const form = event.currentTarget;
    const values = Object.fromEntries(new FormData(form));
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true;
    try {
        const { data, error } = await Gilda.client.auth.signUp({
            email: values.email.trim(),
            password: values.password,
            options: { data: { display_name: values.name.trim() } },
        });
        if (error) throw error;
        form.reset();
        if (data.session) {
            Gilda.user = data.session.user;
            location.href = accountDestination();
        } else {
            Gilda.setMessage('#auth-message', 'Cuenta creada. Revisa tu correo y confirma el registro antes de iniciar sesión.');
        }
    } catch (error) {
        Gilda.setMessage('#auth-message', error.message || 'No se pudo crear la cuenta.', true);
    } finally {
        button.disabled = false;
    }
});

document.querySelector('#login-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!Gilda.client) return Gilda.setMessage('#auth-message', 'No se pudo conectar a Supabase.', true);
    const form = event.currentTarget;
    const values = Object.fromEntries(new FormData(form));
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true;
    try {
        const { data, error } = await Gilda.client.auth.signInWithPassword({ email: values.email.trim(), password: values.password });
        if (error) throw error;
        Gilda.user = data.session.user;
        form.reset();
        location.href = accountDestination();
    } catch (error) {
        Gilda.setMessage('#auth-message', error.message || 'No se pudo iniciar sesión.', true);
    } finally {
        button.disabled = false;
    }
});

document.querySelector('#logout-button').addEventListener('click', async () => {
    const { error } = await Gilda.client.auth.signOut();
    if (error) {
        Gilda.notify(`No se pudo cerrar sesión: ${error.message}`);
        return;
    }
    Gilda.user = null;
    renderAccountPage();
});

async function initAccountPage() {
    try {
        await Gilda.ready();
        renderAccountPage();
    } catch (error) {
        Gilda.setMessage('#auth-message', error.message, true);
    }
}

void initAccountPage();
