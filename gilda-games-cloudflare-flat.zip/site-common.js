(() => {
    const config = window.CHECKPOINT_SUPABASE ?? {};
    const configured = Boolean(config.url && config.publishableKey && !/YOUR_|PEGA_/i.test(`${config.url} ${config.publishableKey}`));
    const client = configured && window.supabase?.createClient
        ? window.supabase.createClient(config.url, config.publishableKey)
        : null;
    const status = document.querySelector('#cloud-status');
    const toast = bootstrap.Toast.getOrCreateInstance(document.querySelector('#app-toast'));
    const state = { client, user: null, profile: null, readyPromise: null };

    function setStatus(message, online = false) {
        if (!status) return;
        status.innerHTML = `<span></span> ${escape(message)}`;
        status.classList.toggle('online', online);
    }

    function updateHeader() {
        const accountLink = document.querySelector('#account-link');
        const adminLink = document.querySelector('[data-admin-link]');
        if (accountLink) {
            const name = state.profile?.display_name || state.user?.user_metadata?.display_name || state.user?.email?.split('@')[0];
            accountLink.innerHTML = state.user ? `${escape(name)} <span>↗</span>` : 'Iniciar sesión <span>↗</span>';
        }
        if (adminLink) adminLink.hidden = !state.isAdmin();
    }

    function escape(value) {
        return String(value ?? '').replace(/[&<>"']/g, (character) => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
        }[character]));
    }

    function gameCard(game, index = 0, entry = null) {
        const labels = { quiero_jugar: 'Quiero jugar', jugando: 'Jugando', terminado: 'Terminado' };
        const marker = entry?.favorite ? '♥' : `★ ${Number(game.rating).toFixed(1)}`;
        const subtitle = entry ? labels[entry.status] : escape(game.genre);
        return `<article class="game-card" style="--card-index:${index}">
            <a class="game-art" href="juego.html?id=${encodeURIComponent(game.id)}"><img loading="lazy" src="${escape(game.cover)}" alt="Portada de ${escape(game.title)}"><span class="card-rating">${marker}</span><span class="card-open">↗</span></a>
            <div class="game-info"><div><a class="game-title" href="juego.html?id=${encodeURIComponent(game.id)}">${escape(game.title)}</a><p>${subtitle} <span>·</span> ${escape(game.platform)}</p></div><span class="game-year">${escape(game.release_year)}</span></div>
        </article>`;
    }

    function setMessage(selector, message, isError = false) {
        const element = document.querySelector(selector);
        if (!element) return;
        element.textContent = message;
        element.classList.toggle('error', isError);
    }

    function notify(message) {
        const messageElement = document.querySelector('#toast-message');
        if (!messageElement) return;
        messageElement.textContent = message;
        toast.show();
    }

    function imageFallback(image) {
        image.addEventListener('error', () => {
            image.style.visibility = 'hidden';
            image.parentElement.style.background = 'linear-gradient(145deg, #dcff67, #f07152)';
        }, { once: true });
    }

    async function ready() {
        if (state.readyPromise) return state.readyPromise;
        state.readyPromise = (async () => {
            if (!client) {
                setStatus('CONFIGURACIÓN PENDIENTE');
                return null;
            }
            setStatus('CONECTANDO A SUPABASE');
            const { data, error } = await client.auth.getSession();
            if (error) throw error;
            state.user = data.session?.user ?? null;
            try {
                await loadProfile();
            } catch (profileError) {
                console.warn('No se pudo cargar el perfil; confirma que ejecutaste supabase-setup.sql.', profileError);
            }
            updateHeader();
            client.auth.onAuthStateChange((_event, session) => {
                state.user = session?.user ?? null;
                state.profile = null;
                updateHeader();
                window.setTimeout(async () => {
                    try {
                        await loadProfile();
                    } catch (profileError) {
                        console.warn('No se pudo actualizar el perfil.', profileError);
                    }
                    updateHeader();
                    window.dispatchEvent(new CustomEvent('gilda:auth', { detail: state.user }));
                }, 0);
            });
            setStatus('SUPABASE ONLINE', true);
            return state.user;
        })();
        return state.readyPromise;
    }

    async function loadProfile() {
        if (!client || !state.user) {
            state.profile = null;
            return null;
        }
        const { data, error } = await client.from('profiles').select('id, email, display_name, role').eq('id', state.user.id).maybeSingle();
        if (error) throw error;
        state.profile = data;
        return data;
    }

    state.isAdmin = () => state.profile?.role === 'admin' || state.user?.app_metadata?.role === 'admin';
    state.escape = escape;
    state.gameCard = gameCard;
    state.imageFallback = imageFallback;
    state.setMessage = setMessage;
    state.notify = notify;
    state.ready = ready;
    state.loadGames = async () => {
        if (!client) throw new Error('Configura Supabase para cargar el catálogo.');
        const { data, error } = await client.from('games').select('*').order('created_at', { ascending: false });
        if (error) throw error;
        return data ?? [];
    };
    state.loadLibrary = async () => {
        if (!state.user) return {};
        const { data, error } = await client.from('user_games').select('game_id, status, is_favorite').eq('user_id', state.user.id);
        if (error) throw error;
        return Object.fromEntries((data ?? []).map((entry) => [entry.game_id, { status: entry.status, favorite: entry.is_favorite }]));
    };
    state.saveLibraryEntry = async (gameId, entry) => {
        if (!state.user) throw new Error('Inicia sesión para guardar juegos.');
        const { error } = await client.from('user_games').upsert({
            user_id: state.user.id,
            game_id: gameId,
            status: entry.status,
            is_favorite: entry.favorite,
        }, { onConflict: 'user_id,game_id' });
        if (error) throw error;
    };
    window.Gilda = state;
    updateHeader();
})();

