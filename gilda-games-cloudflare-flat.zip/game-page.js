const detailState = document.querySelector('#detail-state');
const detailContent = document.querySelector('#detail-content');
let detailGame = null;
let detailLibrary = {};

async function saveDetailEntry(changes) {
    if (!Gilda.user) {
        const next = encodeURIComponent(`${location.pathname.split('/').pop()}${location.search}`);
        location.href = `cuenta.html?next=${next}`;
        return;
    }
    const previous = detailLibrary[detailGame.id] ?? { status: 'quiero_jugar', favorite: false };
    const entry = { ...previous, ...changes };
    await Gilda.saveLibraryEntry(detailGame.id, entry);
    detailLibrary[detailGame.id] = entry;
    updateDetailControls();
    Gilda.notify('Biblioteca actualizada.');
}

function updateDetailControls() {
    document.querySelector('#detail-status').value = detailLibrary[detailGame.id]?.status || 'quiero_jugar';
    document.querySelector('#detail-favorite').textContent = detailLibrary[detailGame.id]?.favorite ? '♥' : '♡';
}

async function initGamePage() {
    const gameId = new URLSearchParams(location.search).get('id');
    if (!gameId) {
        detailState.textContent = 'No se indicó qué juego mostrar.';
        return;
    }
    try {
        await Gilda.ready();
        const [games, library] = await Promise.all([Gilda.loadGames(), Gilda.loadLibrary()]);
        detailGame = games.find((game) => String(game.id) === gameId);
        detailLibrary = library;
        if (!detailGame) {
            detailState.textContent = 'No encontramos ese juego en el catálogo.';
            return;
        }
        document.title = `${detailGame.title} — Gilda Games`;
        document.querySelector('#detail-cover').src = detailGame.cover;
        document.querySelector('#detail-cover').alt = `Portada de ${detailGame.title}`;
        Gilda.imageFallback(document.querySelector('#detail-cover'));
        document.querySelector('#detail-year').textContent = ` / ${detailGame.release_year}`;
        document.querySelector('#detail-title').textContent = detailGame.title;
        document.querySelector('#detail-meta').innerHTML = `<span>${Gilda.escape(detailGame.genre)}</span><span>${Gilda.escape(detailGame.platform)}</span><span>★ ${Number(detailGame.rating).toFixed(1)}</span>`;
        document.querySelector('#detail-description').textContent = detailGame.description || 'Sin descripción.';
        document.querySelector('#detail-developer').textContent = detailGame.developer;
        document.querySelector('#detail-trailer').href = `https://www.youtube.com/results?search_query=${encodeURIComponent(`${detailGame.title} trailer oficial`)}`;
        detailState.hidden = true;
        detailContent.hidden = false;
        updateDetailControls();
    } catch (error) {
        detailState.textContent = `No se pudo cargar el juego: ${error.message}`;
    }
}

document.querySelector('#detail-save').addEventListener('click', () => {
    void saveDetailEntry({ status: document.querySelector('#detail-status').value })
        .catch((error) => Gilda.notify(`No se pudo guardar: ${error.message}`));
});

document.querySelector('#detail-favorite').addEventListener('click', () => {
    if (!detailGame) return;
    void saveDetailEntry({ favorite: !detailLibrary[detailGame.id]?.favorite })
        .catch((error) => Gilda.notify(`No se pudo guardar: ${error.message}`));
});

void initGamePage();
