window.CHECKPOINT_SUPABASE = {
    url: 'https://itwjvlddlrdoffncuhdo.supabase.co',
    publishableKey: 'sb_publishable_F2wqzD0y4Ur7vd7jjd86qA_MDGxojDr',
};