let libraryGames = [];
let libraryEntries = {};
let libraryFilter = 'all';

function renderLibraryPage() {
    const allGames = libraryGames.filter((game) => libraryEntries[game.id]);
    document.querySelector('[data-library-count]').textContent = allGames.length;
    const filtered = allGames.filter((game) => {
        if (libraryFilter === 'favorites') return libraryEntries[game.id].favorite;
        if (libraryFilter === 'all') return true;
        return libraryEntries[game.id].status === libraryFilter;
    });
    const grid = document.querySelector('#library-grid');
    grid.innerHTML = filtered.length
        ? filtered.map((game, index) => Gilda.gameCard(game, index, libraryEntries[game.id])).join('')
        : '<div class="empty-state"><span>＋</span><h3>Tu próxima aventura va aquí</h3><p>Añade juegos desde el catálogo y organiza lo que quieres jugar.</p><a href="juegos.html">Explorar juegos ↗</a></div>';
    grid.querySelectorAll('img').forEach(Gilda.imageFallback);
}

document.querySelector('#library-tabs').addEventListener('click', (event) => {
    const tab = event.target.closest('[data-library-filter]');
    if (!tab) return;
    libraryFilter = tab.dataset.libraryFilter;
    document.querySelectorAll('[data-library-filter]').forEach((button) => button.classList.toggle('active', button === tab));
    renderLibraryPage();
});

async function initLibraryPage() {
    try {
        await Gilda.ready();
        if (!Gilda.user) {
            document.querySelector('#library-grid').innerHTML = '<div class="empty-state"><span>＋</span><h3>Inicia sesión para ver tu biblioteca</h3><p>Tu lista personal se guarda en tu cuenta.</p><a href="cuenta.html">Iniciar sesión ↗</a></div>';
            return;
        }
        document.querySelector('#library-intro').textContent = `Hola, ${Gilda.user.user_metadata?.display_name || Gilda.user.email}. Tus partidas, organizadas a tu manera.`;
        [libraryGames, libraryEntries] = await Promise.all([Gilda.loadGames(), Gilda.loadLibrary()]);
        renderLibraryPage();
    } catch (error) {
        document.querySelector('#library-grid').innerHTML = `<div class="empty-state"><h3>No se pudo cargar tu biblioteca</h3><p>${Gilda.escape(error.message)}</p></div>`;
    }
}

void initLibraryPage();
