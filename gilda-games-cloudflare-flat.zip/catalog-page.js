const catalogGrid = document.querySelector('#game-grid');
let catalogGames = [];

function renderCatalog() {
    const query = document.querySelector('#search-input').value.trim().toLocaleLowerCase('es');
    const genre = document.querySelector('#genre-filter').value;
    const platform = document.querySelector('#platform-filter').value;
    const matches = catalogGames.filter((game) => {
        const searchText = `${game.title} ${game.genre} ${game.developer}`.toLocaleLowerCase('es');
        return searchText.includes(query) && (!genre || game.genre === genre) && (!platform || game.platform === platform);
    });
    document.querySelector('#catalog-count').textContent = `${matches.length} JUEGOS EN EL CATÁLOGO`;
    catalogGrid.innerHTML = matches.length
        ? matches.map((game, index) => Gilda.gameCard(game, index)).join('')
        : '<div class="empty-state"><span>⌕</span><h3>No encontramos ese juego</h3><p>Prueba otro título, género o plataforma.</p></div>';
    catalogGrid.querySelectorAll('img').forEach(Gilda.imageFallback);
}

function renderCatalogFilters() {
    const genres = [...new Set(catalogGames.map((game) => game.genre).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'es'));
    const platforms = [...new Set(catalogGames.map((game) => game.platform).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'es'));
    const fill = (select, values, label) => {
        const selected = select.value;
        select.innerHTML = `<option value="">${label}</option>${values.map((value) => `<option value="${Gilda.escape(value)}">${Gilda.escape(value)}</option>`).join('')}`;
        if (values.includes(selected)) select.value = selected;
    };
    fill(document.querySelector('#genre-filter'), genres, 'Todos los géneros');
    fill(document.querySelector('#platform-filter'), platforms, 'Todas las plataformas');
    document.querySelector('#genre-chips').innerHTML = `<span class="genre-label">GÉNEROS</span>${genres.slice(0, 8).map((genre) => `<button class="genre-chip" type="button" data-genre="${Gilda.escape(genre)}">${Gilda.escape(genre)}</button>`).join('')}`;
}

document.querySelector('#filter-form').addEventListener('submit', (event) => {
    event.preventDefault();
    renderCatalog();
});

document.querySelector('#search-input').addEventListener('input', renderCatalog);
document.querySelector('#genre-filter').addEventListener('change', renderCatalog);
document.querySelector('#platform-filter').addEventListener('change', renderCatalog);
document.querySelector('#genre-chips').addEventListener('click', (event) => {
    const chip = event.target.closest('[data-genre]');
    if (!chip) return;
    document.querySelector('#genre-filter').value = chip.dataset.genre;
    renderCatalog();
});

async function initCatalogPage() {
    try {
        await Gilda.ready();
        catalogGames = await Gilda.loadGames();
        renderCatalogFilters();
        const genre = new URLSearchParams(location.search).get('genero');
        if (genre) document.querySelector('#genre-filter').value = genre;
        renderCatalog();
    } catch (error) {
        document.querySelector('#page-error').textContent = `No se pudo cargar el catálogo: ${error.message}`;
    }
}

void initCatalogPage();
