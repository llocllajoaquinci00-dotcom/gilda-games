let adminGames = [];

function renderAdminList() {
    document.querySelector('#admin-game-count').textContent = adminGames.length;
    document.querySelector('#admin-game-list').innerHTML = adminGames.map((game) => `<div class="admin-row"><div><strong>${Gilda.escape(game.title)}</strong><small>${Gilda.escape(game.genre)} · ${Gilda.escape(game.platform)}</small></div><button type="button" data-edit-game="${Gilda.escape(game.id)}" aria-label="Editar ${Gilda.escape(game.title)}" title="Editar">↗</button><button type="button" data-delete-game="${Gilda.escape(game.id)}" aria-label="Eliminar ${Gilda.escape(game.title)}" title="Eliminar">×</button></div>`).join('');
}

function resetGameForm() {
    const form = document.querySelector('#game-form');
    form.reset();
    form.elements.id.value = '';
    document.querySelector('#game-form-title').textContent = 'Añadir juego';
    document.querySelector('#save-game-button').innerHTML = 'Añadir al catálogo <span>↗</span>';
    document.querySelector('#cancel-edit').hidden = true;
}

async function refreshAdminGames() {
    adminGames = await Gilda.loadGames();
    renderAdminList();
}

document.querySelector('#game-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!Gilda.isAdmin()) return Gilda.notify('Tu cuenta no tiene permisos para administrar juegos.');
    const form = event.currentTarget;
    const values = Object.fromEntries(new FormData(form));
    const cover = values.cover.trim();
    if (cover && new URL(cover).protocol !== 'https:') return Gilda.notify('La portada debe usar una dirección HTTPS.');
    const game = {
        title: values.title.trim(), genre: values.genre.trim(), platform: values.platform.trim(),
        release_year: Number(values.release_year), developer: values.developer.trim(),
        description: values.description.trim(), rating: Number(values.rating), cover,
    };
    const id = values.id.trim();
    const request = id
        ? Gilda.client.from('games').update(game).eq('id', id)
        : Gilda.client.from('games').insert(game);
    const button = document.querySelector('#save-game-button');
    button.disabled = true;
    try {
        const { error } = await request;
        if (error) throw error;
        resetGameForm();
        await refreshAdminGames();
        Gilda.notify(id ? 'Juego actualizado.' : 'Juego agregado al catálogo.');
    } catch (error) {
        Gilda.notify(`No se pudo guardar: ${error.message}`);
    } finally {
        button.disabled = false;
    }
});

document.querySelector('#cancel-edit').addEventListener('click', resetGameForm);

document.querySelector('#admin-game-list').addEventListener('click', async (event) => {
    const editButton = event.target.closest('[data-edit-game]');
    if (editButton) {
        const game = adminGames.find((item) => String(item.id) === editButton.dataset.editGame);
        if (!game) return;
        const form = document.querySelector('#game-form');
        Object.entries(game).forEach(([key, value]) => { if (form.elements[key]) form.elements[key].value = value ?? ''; });
        document.querySelector('#game-form-title').textContent = 'Editar juego';
        document.querySelector('#save-game-button').innerHTML = 'Guardar cambios <span>↗</span>';
        document.querySelector('#cancel-edit').hidden = false;
        form.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
    }
    const deleteButton = event.target.closest('[data-delete-game]');
    if (!deleteButton || !window.confirm('¿Eliminar este juego del catálogo?')) return;
    const { error } = await Gilda.client.from('games').delete().eq('id', deleteButton.dataset.deleteGame);
    if (error) {
        Gilda.notify(`No se pudo eliminar: ${error.message}`);
        return;
    }
    await refreshAdminGames();
    Gilda.notify('Juego eliminado del catálogo.');
});

async function initAdminPage() {
    const accessMessage = document.querySelector('#admin-access-message');
    const adminContent = document.querySelector('#admin-content');
    try {
        await Gilda.ready();
        if (!Gilda.user) {
            accessMessage.innerHTML = 'Inicia sesión con tu cuenta administradora para gestionar el catálogo. <a href="cuenta.html?next=admin.html">Iniciar sesión ↗</a>';
            return;
        }
        if (!Gilda.isAdmin()) {
            accessMessage.textContent = 'Esta cuenta no tiene permisos de administrador.';
            return;
        }
        accessMessage.hidden = true;
        adminContent.hidden = false;
        await refreshAdminGames();
    } catch (error) {
        accessMessage.textContent = `No se pudo abrir administración: ${error.message}`;
    }
}

void initAdminPage();
