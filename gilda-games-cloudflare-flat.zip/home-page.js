async function initHomePage() {
    try {
        await Gilda.ready();
        const games = await Gilda.loadGames();
        const featured = games[0];
        const featuredLink = document.querySelector('#featured-game');
        if (featured) {
            featuredLink.href = `juego.html?id=${encodeURIComponent(featured.id)}`;
            featuredLink.querySelector('img').src = featured.cover;
            featuredLink.querySelector('img').alt = `Portada de ${featured.title}`;
            featuredLink.querySelector('.featured-name').textContent = featured.title;
            featuredLink.querySelector('.featured-subline').textContent = `${featured.genre} · ${featured.platform} · ${featured.release_year}`;
            featuredLink.querySelector('.feature-tag b').textContent = `01 / ${String(games.length).padStart(2, '0')}`;
            Gilda.imageFallback(featuredLink.querySelector('img'));
        } else {
            featuredLink.hidden = true;
        }

        const recentGames = games.slice(0, 4);
        document.querySelector('#home-game-count').textContent = `${games.length} JUEGOS EN EL CATÁLOGO`;
        document.querySelector('#home-games').innerHTML = recentGames.length
            ? recentGames.map((game, index) => Gilda.gameCard(game, index)).join('')
            : '<div class="empty-state"><h3>El catálogo empieza aquí</h3><p>Pronto habrá juegos para explorar.</p></div>';
        document.querySelectorAll('#home-games img').forEach(Gilda.imageFallback);

        const genres = [...new Set(games.map((game) => game.genre).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'es'));
        document.querySelector('#home-genres').innerHTML = genres.slice(0, 6)
            .map((genre) => `<a class="genre-chip" href="juegos.html?genero=${encodeURIComponent(genre)}">${Gilda.escape(genre)} ↗</a>`).join('');
    } catch (error) {
        document.querySelector('#home-error').textContent = `No se pudieron cargar los juegos: ${error.message}`;
    }
}

void initHomePage();
